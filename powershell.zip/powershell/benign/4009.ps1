workflow Write-DebugAndVerboseOutput
{
    "output message"
    write-debug -message "debug message"
    write-verbose -message "verbose message"
}